# GLite
Small graph database engine
